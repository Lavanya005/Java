package com.example.demo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Reservation {
    private int id;
    private int price;
    private int userId;


    public int getId() {
        return id;
    }

    public int getPrice() {
        return price;
    }

    @JsonProperty("user_id")
    public int getUserId() {
        return userId;
    }
}
