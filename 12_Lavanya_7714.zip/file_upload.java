package pkg2;
import java.io.File;  
import java.io.FileNotFoundException; 
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class file_upload {
	public static void main(String[] args) {
		try {
			Scanner i=new Scanner(new File("C:\\Users\\Lavanya\\Friends_name.txt"));
			ArrayList<String> list = new ArrayList<String>();
			while(i.hasNextLine()) {
				list.add(i.nextLine());	
			}
			Iterator it = list.iterator();
			for(int x=0;it.hasNext();x++) {
				System.out.println(it.next());
			}
		    }	   
		catch(FileNotFoundException e) {
			System.out.println(e);
		}
	}
}
