package Dbcon1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class AirlineReservationSystem {
	 boolean[] arrSeats = new boolean[10];
	    Scanner sc = new Scanner(System.in);
	    public boolean assignSeat(String section){
	        if(section == "first"){
	            if(getFreeSeats(section) > 0){
	                for(int i=0; i<5; i++){
	                    if(arrSeats[i] == false){
	                        arrSeats[i] = true;
	                        printBoardingPass(i);
	                        return true;
	                    }
	                }
	            }
	        }else if(section == "economy"){
	            if(getFreeSeats(section) > 0){
	                for(int i=5; i<arrSeats.length; i++){
	                    if(arrSeats[i] == false){
	                        arrSeats[i] = true;
	                        printBoardingPass(i);
	                        return true;
	                    }
	                }

	            }
	        }
	        System.out.printf("All seats in section \"%s\" are booked.\n", section);
	        System.out.printf("Would you like to be moved to section \"%s\" (y/n)? ",
	                (section == "first") ? "economy" : "first");

	        if(sc.next().charAt(0) == 'y')
	            assignSeat((section == "first") ? "economy" : "first");
	        else
	            System.out.println("\nNext flight leaves in 3 hours.\n");

	        return false;
	    }
	    
	    private int getFreeSeats(String section){
	        int total = 0;
	        if(section == "first"){
	            // first class 1-5 (array 0-4)
	            for(int i=0; i<5; i++){
	                if(arrSeats[i] == false)
	                    total += 1;
	            }
	        }else if(section == "economy"){
	            // economy 6-10 (array 5-9)
	            for(int i=5; i<arrSeats.length; i++){
	                if(arrSeats[i] == false)
	                    total += 1;
	            }
	        }
	        return total;
	    }
	    // see whether or not all seats are booked
	    public boolean seatsAvailable(){
	        // if empty seat found return true
	        for(boolean seat : arrSeats)
	            if(seat == false)
	                return true;

	        // if none found plane is full
	        return false;
	    }

	    public void printGreeting(){
	        System.out.println("\nWelcome to XYZ Airlines booking system.\n");
	    }
	    // print the menu with remaining number of seats for each section
	    public void printMenu(){
	        System.out.printf("1. Economy class \n",
	                (getFreeSeats("economy") > 0) ?
	                "(" + Integer.toString(getFreeSeats("economy")) + ")" : "(full)");
	        System.out.printf("2. First class \n",
	                (getFreeSeats("first") > 0 ?
	                 "(" + Integer.toString(getFreeSeats("first")) + ")" : "(full)"));
	        System.out.print("--> ");
	    }
	    // prints the boarding pass
	    private void printBoardingPass(int seat){
	        System.out.println("\nBoarding pass for XYZ Airlines.");
	        System.out.printf("\nSECTION: %s\nSEAT NUMBER: %d\n",
	                (seat < 5) ? "first" : "economy", seat+1);
	    }
	public void bookticket() {
		System.out.println("Hello User! Kindly Enter Your Details...");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Pin No:");
		String pin_no= s.next();
		System.out.println("Enter Departure date:");
		String Departure_date = s.next();
		System.out.println("Enter booking date:");
		String booking_date = s.next();
		System.out.println("Enter user id:");
		String user_id= s.next();
		System.out.println("Enter Passenger Name:");
		String passenger_name= s.next();
		System.out.println("Enter passenger age:");
		String passenger_age= s.next();
		System.out.println("Enter passenger seat:");
		String passengerseat= s.next();
		System.out.println("Your Pin No is:"+pin_no);
		System.out.println("Your booking date is:"+Departure_date);
		System.out.println("Your booking date is:"+booking_date);
		System.out.println("Your user id is:"+user_id);
		System.out.println("Your passenger name is:"+passenger_name);
		System.out.println("Your passenger_age is:"+passenger_age);
		System.out.println("Your passenger seat is:"+passengerseat);
	try {					
		Class.forName("com.mysql.cj.jdbc.Driver");			
		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/database","root","Lava123!@#");  				
		Statement stmt=con.createStatement();  
		String query = " INSERT INTO `database`.`passenger_details` ( `pin_no`, `Departure_date`, `booking_date`,`user_id`,`passenger_name`,`passenger_age`,`passengerseat`) VALUES "
				+ "( '"+ pin_no + "', '"  +   Departure_date  +  " ', ' "  +   booking_date  +  " ', ' "  +   user_id  +  " ', ' "  +   passenger_name  +  " ', ' "  +   passenger_age  +  " ', ' "  +   passengerseat  +  " '); " ;
		int x = stmt.executeUpdate(query);
		con.close();	
		System.out.println("Your Ticket has been Booked successfully ");		
	}catch(SQLException e) {System.out.println(e);}
	catch(ClassNotFoundException e) {System.out.println(e);}
	catch(Exception e) {System.out.println(e);} 
	}
	public void passenger_details() {
		System.out.println("Passenger details for users");
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/database","root","Lava123!@#");  
		Statement stmt=con.createStatement();  
		String query = " select * from passenger_details; " ;
		ResultSet rs=stmt.executeQuery(query);	

		while(rs.next()) {
			
			System.out.println("Pin No -> Departure Date -> Booking_Date -> User_Id -> Passenger Name -> Passenger Age -> Passenger seat No");
			rs.getString("pin_no");
			rs.getString("Departure_date");
			rs.getString("booking_date");
			rs.getString("user_id");
			rs.getString("passenger_name");
			rs.getString("passenger_age");
			rs.getString("passengerseat");
			
			System.out.println(rs.getString("pin_no")+" -> "
			+rs.getString("Departure_date")+" -> "
			+ rs.getString("booking_date")+" -> "
			+ rs.getString("user_id")+" -> "
			+ rs.getString("passenger_name")+" -> "
			+ rs.getString("passenger_age")+" -> "
			+ rs.getString("passengerseat")        );
		}
		con.close(); 
	} catch(ClassNotFoundException e) {System.out.println(e);}
	catch (SQLException e) {System.out.println(e);}
	catch (Exception e) {System.out.println(e);}
	}
	public void Book_flight() {
		System.out.println("List of Flight booked");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/database","root","Lava123!@#");  		
			Statement stmt=con.createStatement();  				
			String query = " select * from flight_booked; " ;
			ResultSet rs=stmt.executeQuery(query);				
			while(rs.next()) {
				
				System.out.println("trans_id -> user_id -> from -> to -> Date -> Flight_id -> Price -> Airlines_type -> No of ticket -> Total Amount -> Paid");
				rs.getString("trans_id");
				rs.getString("userid");
				rs.getString("from");
				rs.getString("to");
				rs.getString("date");
				rs.getString("flight_id");
				rs.getString("price");
				rs.getString("airlines_type");
				rs.getString("no_of_ticket");
				rs.getString("total_amt");
				rs.getString("paid");
				
				System.out.println(rs.getString("trans_id")+" -> "
				+rs.getString("userid")+" -> "
				+ rs.getString("from")+" -> "
				+ rs.getString("to")+" -> "
				+ rs.getString("date")+" -> "
				+ rs.getString("flight_id")+" -> "
				+ rs.getString("price")+" -> "
				+ rs.getString("airlines_type")+" -> "
				+ rs.getString("no_of_ticket")+" -> "
				+ rs.getString("total_amt")+" -> "
				+ rs.getString("paid")        );
			}
			con.close(); 
		} catch(ClassNotFoundException e) {System.out.println(e);}
		catch (SQLException e) {System.out.println(e);}
		catch (Exception e) {System.out.println(e);}
		}
	public static void main(String[] args) {
		AirlineReservationSystem a = new AirlineReservationSystem();
		a.assignSeat("first");
    	a.seatsAvailable();
    	a.printGreeting();
    	a.printMenu();
		a.bookticket();
		a.passenger_details();
		a.Book_flight();
		
	}

}



